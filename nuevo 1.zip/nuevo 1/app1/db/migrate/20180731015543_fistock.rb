class Fistock < ActiveRecord::Migration[5.0]
  def change
  	add_reference :stocks, :product
  	add_reference :stocks, :store
  end
end
