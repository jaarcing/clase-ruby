class Nuevo < ApplicationRecord
end
