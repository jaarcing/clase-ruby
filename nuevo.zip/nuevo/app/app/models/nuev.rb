class Nuev < ApplicationRecord
end
