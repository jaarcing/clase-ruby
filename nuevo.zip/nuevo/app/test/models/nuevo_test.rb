require 'test_helper'

class NuevoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
