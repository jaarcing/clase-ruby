Rails.application.routes.draw do
  get 'bookstore/index'

  devise_for :users
  root to: "author#index"
  get 'author/index'
  get 'autores', to: "author#index"

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
