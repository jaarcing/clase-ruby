class AuthorController < ApplicationController
  def index
  	@authors = Author.all
  	@books =Book1.all
  end
end
