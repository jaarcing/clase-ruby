class Book1 < ApplicationRecord
  belongs_to :author
end
