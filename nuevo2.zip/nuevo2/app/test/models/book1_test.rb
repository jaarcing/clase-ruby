require 'test_helper'

class Book1Test < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
