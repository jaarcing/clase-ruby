module LocationHelper
end
